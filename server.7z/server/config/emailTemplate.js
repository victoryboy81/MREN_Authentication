// https://stripo.email/templates/
//for html template
export const EMAIL_VERIFY_TEMPLATE = ``;
export const PASSWORD_RESET_TEMPLATE = ``;
